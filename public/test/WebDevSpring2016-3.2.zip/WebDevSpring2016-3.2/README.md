** Note To TA **
Openshift server is broken. 
Please clone the repo locally, and use the following homepage link,
http://localhost:3000/index.html
____________________________________________________________________

The OpenShift `nodejs` cartridge documentation can be found at:

http://openshift.github.io/documentation/oo_cartridge_guide.html#nodejs

