/**
 * Created by Kushagra on 2/22/2016.
 */
console.log("hello from scripts.js");
