(function() {
    angular
        .module("MovieApp", ["ngRoute"]);
})();