(function () {

    "use strict";

    angular
        .module('App', []);

})();