(function () {
    "use strict";

    angular
        .module("FormBuilderApp", ["ngRoute"]);
})();
