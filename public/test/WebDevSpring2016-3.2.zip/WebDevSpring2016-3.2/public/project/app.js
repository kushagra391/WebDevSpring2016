/**
 * Created by Kushagra on 3/12/2016.
 */

(function() {
    angular
        .module('CourseraApp', ['ngRoute']);
})();